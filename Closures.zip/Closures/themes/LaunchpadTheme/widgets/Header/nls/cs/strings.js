﻿define(
   ({
    _widgetLabel: "Záhlaví",
    signin: "Přihlásit",
    signout: "Odhlásit",
    about: "O produktu",
    signInTo: "Přihlásit se do",
    cantSignOutTip: "Tato funkce není v režimu náhledu k dispozici."
  })
);
