﻿define(
   ({
    _widgetLabel: "رأس الصفحة",
    signin: "تسجيل الدخول",
    signout: "تسجيل الخروج",
    about: "حول",
    signInTo: "تسجيل الدخول إلى",
    cantSignOutTip: "يتم تطبيق هذه الوظيفة في وضع المعاينة."
  })
);
