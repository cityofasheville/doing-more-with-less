﻿define(
   ({
    _widgetLabel: "כותרת עליונה",
    signin: "הירשם",
    signout: "התנתק",
    about: "אודות",
    signInTo: "התחבר אל",
    cantSignOutTip: "פונקציה זו אינה זמינה במצב תצוגה מקדימה."
  })
);
