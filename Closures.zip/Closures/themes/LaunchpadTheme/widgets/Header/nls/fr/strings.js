﻿define(
   ({
    _widgetLabel: "En-tête",
    signin: "Connexion",
    signout: "Déconnexion",
    about: "À propos de",
    signInTo: "Se connecter à",
    cantSignOutTip: "Cette fonction est N/D en mode d’aperçu."
  })
);
