﻿define(
   ({
    _widgetLabel: "Cabeçalho",
    signin: "Acessar",
    signout: "Sair",
    about: "Sobre o",
    signInTo: "Entrar no",
    cantSignOutTip: "Esta função é N/A no modo de visualização."
  })
);
