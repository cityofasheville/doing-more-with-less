﻿define(
   ({
    _widgetLabel: "ส่วนหัว",
    signin: "ลงชื่อเข้าใช้",
    signout: "ลงชื่อออก",
    about: "เกี่ยวกับ",
    signInTo: "เข้าสู่ระบบ",
    cantSignOutTip: "ฟังก์ชันนี้ไม่มีในโหมดการแสดงตัวอย่าง"
  })
);
