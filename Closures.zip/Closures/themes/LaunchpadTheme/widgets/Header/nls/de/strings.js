﻿define(
   ({
    _widgetLabel: "Kopfzeile",
    signin: "Anmelden",
    signout: "Abmelden",
    about: "Informationen zu",
    signInTo: "Melden Sie sich an bei",
    cantSignOutTip: "Diese Funktion ist im Vorschaumodus nicht zutreffend."
  })
);
