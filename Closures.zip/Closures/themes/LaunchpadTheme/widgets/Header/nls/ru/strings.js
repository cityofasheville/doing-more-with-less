﻿define(
   ({
    _widgetLabel: "Заголовок",
    signin: "Вход",
    signout: "Выход",
    about: "О приложении",
    signInTo: "Войти в",
    cantSignOutTip: "Эта функция недоступна в режиме предварительного просмотра."
  })
);
