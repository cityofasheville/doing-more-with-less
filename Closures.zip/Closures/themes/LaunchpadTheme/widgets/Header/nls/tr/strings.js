﻿define(
   ({
    _widgetLabel: "Başlık",
    signin: "Oturum Açma",
    signout: "Oturum Kapat",
    about: "Hakkında",
    signInTo: "Şurada oturum aç:",
    cantSignOutTip: "Bu işlev ön izleme modunda yok."
  })
);
