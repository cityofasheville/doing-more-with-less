﻿define(
   ({
    _widgetLabel: "Ankurriba kontroller",
    _layout_default: "Vaikimisi paigutus",
    _layout_layout1: "Paigutus 0",
    more: 'Rohkem vidinaid'
  })
);