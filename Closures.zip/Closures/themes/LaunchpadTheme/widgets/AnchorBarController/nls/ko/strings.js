﻿define(
   ({
    _widgetLabel: "고정 막대형 컨트롤러",
    _layout_default: "기본 레이아웃",
    _layout_layout1: "레이아웃 0",
    more: '더 많은 위젯'
  })
);