﻿define(
   ({
    _widgetLabel: "แถบควบคุมหลัก",
    _layout_default: "โครงร่างตั้งต้น",
    _layout_layout1: "โครงร่าง 0",
    more: 'วิดเจทอื่น'
  })
);