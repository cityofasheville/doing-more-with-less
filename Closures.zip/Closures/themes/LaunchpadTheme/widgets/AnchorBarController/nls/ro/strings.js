﻿define(
   ({
    _widgetLabel: "Controller bară ancorare",
    _layout_default: "Configuraţie implicită",
    _layout_layout1: "Aspectul 0",
    more: 'Mai multe widgeturi'
  })
);