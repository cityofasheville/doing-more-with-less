﻿define(
   ({
    _widgetLabel: "Balkbediening verankeren",
    _layout_default: "Standaard lay-out",
    _layout_layout1: "Lay-out 0",
    more: 'Meer Widgets'
  })
);