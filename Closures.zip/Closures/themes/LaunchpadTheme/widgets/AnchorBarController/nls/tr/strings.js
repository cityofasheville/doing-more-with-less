﻿define(
   ({
    _widgetLabel: "Tutturucu Çubuğu Denetleyicisi",
    _layout_default: "Varsayılan Düzen",
    _layout_layout1: "Düzen 0",
    more: 'Diğer Gereçler'
  })
);