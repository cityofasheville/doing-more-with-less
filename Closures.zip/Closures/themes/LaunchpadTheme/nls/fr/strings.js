﻿define(
   ({
    _themeLabel: "Thème Launchpad",
    _layout_default: "Mise en page par défaut",
    _layout_right: "Mise en page de droite"
  })
);