﻿define(
   ({
    _themeLabel: "Θέμα Launchpad",
    _layout_default: "Προκαθορισμένη διάταξη",
    _layout_right: "Διάταξη στα δεξιά"
  })
);