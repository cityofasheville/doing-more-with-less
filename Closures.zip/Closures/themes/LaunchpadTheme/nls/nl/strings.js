﻿define(
   ({
    _themeLabel: "Launchpad Thema",
    _layout_default: "Standaard lay-out",
    _layout_right: "Lay-out rechts"
  })
);