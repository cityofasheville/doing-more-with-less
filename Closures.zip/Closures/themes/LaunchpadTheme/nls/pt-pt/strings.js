﻿define(
   ({
    _themeLabel: "Tema Plataforma de Lançamento",
    _layout_default: "Layout Padrão",
    _layout_right: "Layout Direita"
  })
);