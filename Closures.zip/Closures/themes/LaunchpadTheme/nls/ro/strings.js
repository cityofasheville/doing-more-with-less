﻿define(
   ({
    _themeLabel: "Temă platformă lansare",
    _layout_default: "Configuraţie implicită",
    _layout_right: "Aspect corect"
  })
);