﻿define(
   ({
    _themeLabel: "Palaišanas paneļa dizains",
    _layout_default: "Noklusējuma izkārtojums",
    _layout_right: "Pareizs izkārtojums"
  })
);