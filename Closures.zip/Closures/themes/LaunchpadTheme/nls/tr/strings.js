﻿define(
   ({
    _themeLabel: "Fırlatma Rampası Teması",
    _layout_default: "Varsayılan Düzen",
    _layout_right: "Doğru Düzen"
  })
);