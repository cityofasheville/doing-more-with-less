﻿define(
   ({
    _themeLabel: "נושא Launchpad",
    _layout_default: "פריסת ברירת מחדל",
    _layout_right: "פריסה ימנית"
  })
);