﻿define(
   ({
    _themeLabel: "Motyw Launchpad",
    _layout_default: "Układ domyślny",
    _layout_right: "Układ prawostronny"
  })
);