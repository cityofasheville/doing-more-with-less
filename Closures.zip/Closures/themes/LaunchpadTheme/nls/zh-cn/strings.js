﻿define(
   ({
    _themeLabel: "快速启动板主题",
    _layout_default: "默认布局",
    _layout_right: "正确布局"
  })
);