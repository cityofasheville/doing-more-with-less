﻿define(
   ({
    _themeLabel: "Tema da Plataforma de Inicialização",
    _layout_default: "Layout Padrão",
    _layout_right: "Layout Direito"
  })
);