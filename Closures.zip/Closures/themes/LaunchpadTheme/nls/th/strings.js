﻿define(
   ({
    _themeLabel: "ธีมลอนช์แพด",
    _layout_default: "โครงร่างตั้งต้น",
    _layout_right: "โครงร่างชิดขวา"
  })
);