﻿define(
   ({
    _themeLabel: "Startfelt-tema",
    _layout_default: "Standard oppsett",
    _layout_right: "Høyreoppsett"
  })
);