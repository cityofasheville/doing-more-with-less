﻿define(
   ({
    instruction: "Erstellen Sie den Inhalt, der in diesem Widget angezeigt wird.",
    defaultContent: "Hier können Sie Text, Links und kleine Grafiken hinzufügen.",
    productVersion: "Produktversion: ",
    kernelVersion: "Kernel-Version: "
  })
);