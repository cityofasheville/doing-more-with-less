﻿define(
   ({
    instruction: "Opprett innholdet som skal vises i denne widgeten.",
    defaultContent: "Legg til tekst, koblinger og små grafikkelementer her.",
    productVersion: "Produktversjon: ",
    kernelVersion: "Kernel-versjon: "
  })
);