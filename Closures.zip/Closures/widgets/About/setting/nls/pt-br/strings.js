﻿define(
   ({
    instruction: "Cria o conteúdo que será mostrado neste widget.",
    defaultContent: "Adicione texto, links e gráficos pequenos aqui.",
    productVersion: "Versão do Produto: ",
    kernelVersion: "Versão do Kernel: "
  })
);