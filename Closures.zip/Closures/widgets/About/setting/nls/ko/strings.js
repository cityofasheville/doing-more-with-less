﻿define(
   ({
    instruction: "이 위젯에 나타나는 콘텐츠를 만듭니다.",
    defaultContent: "텍스트, 링크 및 작은 그래픽을 여기에 추가합니다.",
    productVersion: "제품 버전: ",
    kernelVersion: "커널 버전: "
  })
);