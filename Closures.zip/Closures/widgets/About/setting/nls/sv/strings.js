﻿define(
   ({
    instruction: "Skapa innehållet som ska visas i widgeten.",
    defaultContent: "Lägg till texter, länkar och små bilder här.",
    productVersion: "Produktversion: ",
    kernelVersion: "Kärnversion: "
  })
);