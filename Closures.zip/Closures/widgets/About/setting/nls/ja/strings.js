﻿define(
   ({
    instruction: "このウィジェットに表示されるコンテンツを作成します。",
    defaultContent: "ここにテキスト、リンク、および小さなグラフィックスを追加します。",
    productVersion: "製品バージョン: ",
    kernelVersion: "カーネル バージョン: "
  })
);