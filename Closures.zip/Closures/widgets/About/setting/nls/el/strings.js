﻿define(
   ({
    instruction: "Δημιουργήστε το περιεχόμενο που εμφανίζεται σε αυτό το widget.",
    defaultContent: "Προσθέστε κείμενο, συνδέσμους και μικρά γραφικά εδώ.",
    productVersion: "Έκδοση προϊόντος: ",
    kernelVersion: "Έκδοση πυρήνα: "
  })
);