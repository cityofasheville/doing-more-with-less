﻿define(
   ({
    instruction: "Opret det indhold, der skal vises i denne widget.",
    defaultContent: "Tilføj tekst, links og små billeder her.",
    productVersion: "Produktversion: ",
    kernelVersion: "Kernel-version: "
  })
);