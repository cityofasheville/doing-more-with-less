﻿define(
   ({
    _widgetLabel: "Despre"
  })
);