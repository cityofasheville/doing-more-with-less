﻿define(
   ({
    _widgetLabel: "אודות"
  })
);