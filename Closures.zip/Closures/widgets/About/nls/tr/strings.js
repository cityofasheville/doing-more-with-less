﻿define(
   ({
    _widgetLabel: "Hakkında"
  })
);