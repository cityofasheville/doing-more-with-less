﻿define(
   ({
    _widgetLabel: "Info"
  })
);