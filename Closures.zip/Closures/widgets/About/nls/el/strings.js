﻿define(
   ({
    _widgetLabel: "Πληροφορίες"
  })
);