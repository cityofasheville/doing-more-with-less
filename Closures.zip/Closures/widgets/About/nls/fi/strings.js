﻿define(
   ({
    _widgetLabel: "Tietoja"
  })
);