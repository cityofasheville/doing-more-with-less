﻿define(
   ({
    _widgetLabel: "Par"
  })
);