﻿define(
   ({
    _widgetLabel: "關於"
  })
);