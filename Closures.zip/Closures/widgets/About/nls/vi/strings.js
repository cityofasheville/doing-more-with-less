﻿define(
   ({
    _widgetLabel: "Về"
  })
);