﻿define(
   ({
    _widgetLabel: "Informazioni"
  })
);