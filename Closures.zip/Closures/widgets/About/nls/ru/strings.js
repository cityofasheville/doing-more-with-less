﻿define(
   ({
    _widgetLabel: "О"
  })
);