﻿define(
   ({
    _widgetLabel: "Apie"
  })
);