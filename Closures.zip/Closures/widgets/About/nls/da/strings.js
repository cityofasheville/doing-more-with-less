﻿define(
   ({
    _widgetLabel: "Om"
  })
);