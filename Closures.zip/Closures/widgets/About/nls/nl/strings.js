﻿define(
   ({
    _widgetLabel: "Over"
  })
);