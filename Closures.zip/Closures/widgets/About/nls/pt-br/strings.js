﻿define(
   ({
    _widgetLabel: "Sobre"
  })
);