﻿define(
   ({
    _widgetLabel: "Informacje o"
  })
);