﻿define(
   ({
    _widgetLabel: "정보"
  })
);